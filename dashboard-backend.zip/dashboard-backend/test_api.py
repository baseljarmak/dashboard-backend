#!/usr/bin/env python3
"""
Test script for Dashboard API
Tests authentication, CSV upload, and data operations
"""

import requests
import json
from pathlib import Path

# Configuration
BASE_URL = "http://localhost:8000"
API_V1 = f"{BASE_URL}/api/v1"

def print_section(title):
    """Print formatted section header."""
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}\n")

def test_health_check():
    """Test health endpoint."""
    print_section("1. Health Check")
    
    response = requests.get(f"{BASE_URL}/health")
    print(f"Status: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
    
    return response.status_code == 200

def test_authentication():
    """Test authentication and get token."""
    print_section("2. Authentication")
    
    # Test login
    login_data = {
        "username": "admin",
        "password": "admin123"
    }
    
    response = requests.post(f"{API_V1}/auth/login", json=login_data)
    print(f"Status: {response.status_code}")
    
    if response.status_code == 200:
        data = response.json()
        token = data.get("access_token")
        print(f"✅ Login successful!")
        print(f"Token (first 50 chars): {token[:50]}...")
        
        # Test get current user
        headers = {"Authorization": f"Bearer {token}"}
        me_response = requests.get(f"{API_V1}/auth/me", headers=headers)
        
        if me_response.status_code == 200:
            user_data = me_response.json()
            print(f"\nCurrent User Info:")
            print(f"  Username: {user_data.get('username')}")
            print(f"  Email: {user_data.get('email')}")
            print(f"  Roles: {user_data.get('roles')}")
        
        return token
    else:
        print(f"❌ Login failed!")
        print(f"Response: {response.text}")
        return None

def test_csv_upload(token):
    """Test CSV upload."""
    print_section("3. CSV Upload")
    
    csv_path = Path("data/sample_sales.csv")
    
    if not csv_path.exists():
        print(f"❌ Sample CSV not found at {csv_path}")
        return False
    
    headers = {"Authorization": f"Bearer {token}"}
    
    with open(csv_path, 'rb') as f:
        files = {'file': ('sample_sales.csv', f, 'text/csv')}
        response = requests.post(f"{API_V1}/data/upload", headers=headers, files=files)
    
    print(f"Status: {response.status_code}")
    
    if response.status_code == 200:
        data = response.json()
        print(f"✅ Upload successful!")
        print(f"  Filename: {data.get('filename')}")
        print(f"  Rows processed: {data.get('rows_processed'):,}")
        print(f"  Columns: {', '.join(data.get('columns', []))}")
        print(f"  File size: {data.get('file_size_mb')} MB")
        print(f"  Processing time: {data.get('processing_time_ms')} ms")
        return True
    else:
        print(f"❌ Upload failed!")
        print(f"Response: {response.text}")
        return False

def test_get_dimensions(token):
    """Test getting available dimensions."""
    print_section("4. Get Available Dimensions")
    
    headers = {"Authorization": f"Bearer {token}"}
    response = requests.get(f"{API_V1}/data/dimensions", headers=headers)
    
    print(f"Status: {response.status_code}")
    
    if response.status_code == 200:
        data = response.json()
        print(f"✅ Dimensions retrieved!")
        print(f"  Segments: {', '.join(data.get('segments', []))}")
        print(f"  Date columns: {', '.join(data.get('date_columns', []))}")
        print(f"  Numeric columns: {', '.join(data.get('numeric_columns', []))}")
        return True
    else:
        print(f"❌ Failed to get dimensions!")
        print(f"Response: {response.text}")
        return False

def test_create_cube(token):
    """Test creating OLAP cube."""
    print_section("5. Create OLAP Cube")
    
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    
    filter_request = {
        "group_by": ["category", "region"],
        "metrics": ["revenue", "quantity"],
        "aggregation": "sum",
        "limit": 20
    }
    
    response = requests.post(f"{API_V1}/data/cube", headers=headers, json=filter_request)
    
    print(f"Status: {response.status_code}")
    
    if response.status_code == 200:
        data = response.json()
        print(f"✅ Cube created!")
        print(f"  Dimensions: {', '.join(data.get('dimensions', []))}")
        print(f"  Measures: {', '.join(data.get('measures', []))}")
        print(f"  Total records: {data.get('total_records')}")
        print(f"  Query time: {data.get('query_time_ms')} ms")
        print(f"\n  Sample data (first 3 rows):")
        
        for i, row in enumerate(data.get('data', [])[:3]):
            print(f"    Row {i+1}: {row}")
        
        return True
    else:
        print(f"❌ Failed to create cube!")
        print(f"Response: {response.text}")
        return False

def test_get_chart_data(token):
    """Test getting chart-ready data."""
    print_section("6. Get Chart Data")
    
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    
    filter_request = {
        "group_by": ["category"],
        "metrics": ["revenue"],
        "aggregation": "sum"
    }
    
    response = requests.post(f"{API_V1}/data/chart", headers=headers, json=filter_request)
    
    print(f"Status: {response.status_code}")
    
    if response.status_code == 200:
        data = response.json()
        print(f"✅ Chart data retrieved!")
        print(f"  Title: {data.get('title')}")
        print(f"  Labels: {', '.join(data.get('labels', []))}")
        print(f"  Total records: {data.get('total_records')}")
        
        for dataset in data.get('datasets', []):
            print(f"\n  Dataset: {dataset.get('name')}")
            print(f"    Type: {dataset.get('type')}")
            print(f"    Data: {dataset.get('data')}")
        
        return True
    else:
        print(f"❌ Failed to get chart data!")
        print(f"Response: {response.text}")
        return False

def test_get_summary(token):
    """Test getting data summary."""
    print_section("7. Get Data Summary")
    
    headers = {"Authorization": f"Bearer {token}"}
    response = requests.get(f"{API_V1}/data/summary", headers=headers)
    
    print(f"Status: {response.status_code}")
    
    if response.status_code == 200:
        data = response.json()
        print(f"✅ Summary retrieved!")
        print(f"  Total records: {data.get('total_records'):,}")
        
        if data.get('date_range'):
            print(f"  Date range: {data['date_range']['start_date']} to {data['date_range']['end_date']}")
        
        print(f"  Segments: {len(data.get('segments', []))} unique values")
        
        print(f"\n  Metrics summary:")
        for metric, stats in data.get('metrics', {}).items():
            print(f"    {metric}:")
            print(f"      Sum: {stats.get('sum'):,.2f}")
            print(f"      Avg: {stats.get('avg'):,.2f}")
            print(f"      Min: {stats.get('min'):,.2f}")
            print(f"      Max: {stats.get('max'):,.2f}")
        
        return True
    else:
        print(f"❌ Failed to get summary!")
        print(f"Response: {response.text}")
        return False

def main():
    """Run all tests."""
    print("\n" + "="*60)
    print("  DASHBOARD API TEST SUITE")
    print("="*60)
    print(f"\nTesting API at: {BASE_URL}")
    print("Make sure the server is running with: uvicorn app.main:app --reload")
    
    # Test health
    if not test_health_check():
        print("\n❌ Server is not responding! Please start the server first.")
        return
    
    # Test authentication
    token = test_authentication()
    if not token:
        print("\n❌ Authentication failed! Cannot proceed with other tests.")
        return
    
    # Test CSV upload
    if not test_csv_upload(token):
        print("\n⚠️  CSV upload failed! Some tests may not work.")
    
    # Test other endpoints
    test_get_dimensions(token)
    test_create_cube(token)
    test_get_chart_data(token)
    test_get_summary(token)
    
    # Summary
    print_section("Test Summary")
    print("✅ All tests completed!")
    print("\nNext steps:")
    print("1. Check the API docs at: http://localhost:8000/docs")
    print("2. Integrate with your frontend (React/Angular)")
    print("3. Upload your own CSV files (millions of rows supported!)")
    print("4. Create custom dashboards with drag-and-drop")

if __name__ == "__main__":
    try:
        main()
    except requests.exceptions.ConnectionError:
        print("\n❌ Error: Cannot connect to server!")
        print("Please start the server first with:")
        print("  uvicorn app.main:app --reload")
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")