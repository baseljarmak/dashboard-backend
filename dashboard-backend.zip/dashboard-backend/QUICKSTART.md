# Quick Start Guide - Dashboard Backend

Get your FastAPI backend running in 5 minutes!

## Prerequisites

- Python 3.9+ installed
- pip installed
- (Optional) Docker for containerized deployment

## Option 1: Local Development (Recommended for development)

### Step 1: Setup

```bash
# Navigate to project directory
cd dashboard-backend

# Create virtual environment
python3 -m venv venv

# Activate virtual environment
# On macOS/Linux:
source venv/bin/activate
# On Windows:
venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### Step 2: Configure Environment

```bash
# Copy environment template
cp .env.example .env

# Generate a secure secret key
python -c "import secrets; print(secrets.token_urlsafe(32))"

# Edit .env and paste the generated key as SECRET_KEY
nano .env  # or use your favorite editor
```

### Step 3: Run the Server

```bash
# Start the server
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

**Or use the convenience script:**

```bash
chmod +x run.sh
./run.sh
```

### Step 4: Test the API

Open another terminal:

```bash
# Make test script executable
chmod +x test_api.py

# Run tests
python test_api.py
```

**Or test manually:**

1. Visit: http://localhost:8000/docs
2. Click "Authorize" button
3. Login with:
   - Username: `admin`
   - Password: `admin123`
4. Try the endpoints!

## Option 2: Docker (Recommended for production)

### Step 1: Build and Run

```bash
# Build and start container
docker-compose up --build

# Or run in background
docker-compose up -d
```

### Step 2: Test

```bash
# Check if running
curl http://localhost:8000/health

# Run test script
python test_api.py
```

### Step 3: Stop

```bash
docker-compose down
```

## First API Call

### 1. Get Access Token

```bash
curl -X POST "http://localhost:8000/api/v1/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"username": "admin", "password": "admin123"}'
```

**Response:**
```json
{
  "access_token": "eyJhbGc...",
  "token_type": "bearer"
}
```

Copy the `access_token` value.

### 2. Upload Sample CSV

```bash
curl -X POST "http://localhost:8000/api/v1/data/upload" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -F "file=@data/sample_sales.csv"
```

### 3. Get Chart Data

```bash
curl -X POST "http://localhost:8000/api/v1/data/chart" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -H "Content-Type: application/json" \
  -d '{
    "group_by": ["category"],
    "metrics": ["revenue"],
    "aggregation": "sum"
  }'
```

## Testing with Millions of Records

### Generate Large CSV

```python
# generate_large_csv.py
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

# Generate 1 million rows
num_rows = 1_000_000

dates = [datetime(2024, 1, 1) + timedelta(days=i % 365) for i in range(num_rows)]
categories = np.random.choice(['Electronics', 'Furniture', 'Clothing', 'Food'], num_rows)
regions = np.random.choice(['North', 'South', 'East', 'West'], num_rows)
revenue = np.random.uniform(10, 1000, num_rows).round(2)
quantity = np.random.randint(1, 50, num_rows)

df = pd.DataFrame({
    'date': dates,
    'category': categories,
    'region': regions,
    'revenue': revenue,
    'quantity': quantity,
    'cost': (revenue * np.random.uniform(0.6, 0.8, num_rows)).round(2)
})

df.to_csv('data/large_sales.csv', index=False)
print(f"Generated {num_rows:,} rows")
```

```bash
# Run generator
pip install pandas numpy
python generate_large_csv.py

# Upload large file
curl -X POST "http://localhost:8000/api/v1/data/upload" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -F "file=@data/large_sales.csv"
```

## Next Steps

### Frontend Integration

Your frontend can now connect to:

**Base URL:** `http://localhost:8000`

**Endpoints:**
- POST `/api/v1/auth/login` - Get token
- POST `/api/v1/data/upload` - Upload CSV
- GET `/api/v1/data/dimensions` - Get available fields
- POST `/api/v1/data/cube` - Query data cube
- POST `/api/v1/data/chart` - Get chart data
- GET `/api/v1/data/summary` - Get summary stats

**Example React Integration:**

```javascript
// api.js
const API_BASE = 'http://localhost:8000/api/v1';

export const login = async (username, password) => {
  const response = await fetch(`${API_BASE}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password })
  });
  return response.json();
};

export const getChartData = async (token, filters) => {
  const response = await fetch(`${API_BASE}/data/chart`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(filters)
  });
  return response.json();
};

// Usage in component
const ChartComponent = () => {
  const [data, setData] = useState(null);
  
  useEffect(() => {
    const fetchData = async () => {
      const chartData = await getChartData(token, {
        group_by: ['category'],
        metrics: ['revenue'],
        aggregation: 'sum'
      });
      setData(chartData);
    };
    fetchData();
  }, []);
  
  return <EChartsReact option={transformToECharts(data)} />;
};
```

### Production Deployment

1. **Set environment variables:**
   ```bash
   DEBUG=False
   SECRET_KEY=<strong-random-key>
   ALLOWED_ORIGINS=https://yourdomain.com
   ```

2. **Use reverse proxy (Nginx):**
   ```nginx
   location /api {
       proxy_pass http://localhost:8000;
   }
   ```

3. **Enable HTTPS** (Let's Encrypt)

4. **Add rate limiting** and security headers

## Troubleshooting

**Server won't start:**
- Check if port 8000 is available: `lsof -i :8000`
- Check logs for errors
- Verify Python version: `python --version` (need 3.9+)

**Can't upload CSV:**
- Check file size (max 500MB by default)
- Verify file is actually CSV format
- Check token is valid (not expired)

**Slow queries:**
- Add date range filters
- Limit result size
- Use specific aggregations
- Consider indexing for very large datasets

## Help & Documentation

- **API Docs:** http://localhost:8000/docs
- **README:** Full documentation in README.md
- **Test Script:** Run `python test_api.py` for diagnostics

## Default Users

- **Admin:** username: `admin`, password: `admin123`
  - Roles: admin, analyst
  - Can upload, query, and delete data

- **Analyst:** username: `analyst`, password: `analyst123`
  - Roles: analyst
  - Can upload and query data

**⚠️ Change these passwords in production!**

---

Happy coding! 🚀
