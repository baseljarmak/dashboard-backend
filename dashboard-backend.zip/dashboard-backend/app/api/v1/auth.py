from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from datetime import timedelta
from app.models.schemas import Token, User, UserLogin
from app.core.security import (
    verify_password,
    get_password_hash,
    create_access_token,
    get_current_user
)
from app.core.config import get_settings

settings = get_settings()
router = APIRouter(prefix="/auth", tags=["Authentication"])

# Mock user database - passwords stored as plain text, hashed on-demand
fake_users_db = {
    "admin": {
        "username": "admin",
        "full_name": "Admin User",
        "email": "admin@dashboard.com",
        "plain_password": "admin123",
        "roles": ["admin", "analyst"],
        "disabled": False
    },
    "analyst": {
        "username": "analyst",
        "full_name": "Data Analyst",
        "email": "analyst@dashboard.com",
        "plain_password": "analyst123",
        "roles": ["analyst"],
        "disabled": False
    }
}

# Cache for hashed passwords (lazy initialization)
_hashed_passwords = {}


def get_user_hashed_password(username: str) -> str:
    """Get or create hashed password for a user (lazy loading)."""
    if username not in _hashed_passwords:
        user = fake_users_db.get(username)
        if user and "plain_password" in user:
            _hashed_passwords[username] = \
                get_password_hash(user["plain_password"])
    return _hashed_passwords.get(username)


def authenticate_user(username: str, password: str):
    """Authenticate user credentials."""
    user = fake_users_db.get(username)
    if not user:
        return False

    # Get the hashed password (will be cached after first call)
    hashed_password = get_user_hashed_password(username)

    if not hashed_password:
        return False

    if not verify_password(password, hashed_password):
        return False

    return user


@router.post("/token", response_model=Token)
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    """
    OAuth2 compatible token login, get an access token for future requests.

    Default users:
    - Username: admin, Password: admin123 (roles: admin, analyst)
    - Username: analyst, Password: analyst123 (roles: analyst)
    """
    user = authenticate_user(form_data.username, form_data.password)

    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )

    if user.get("disabled"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Inactive user"
        )

    access_token_expires = timedelta(
        minutes=settings.access_token_expire_minutes)
    access_token = create_access_token(
        data={"sub": user["username"], "roles": user["roles"]},
        expires_delta=access_token_expires
    )

    return {"access_token": access_token, "token_type": "bearer"}


@router.post("/login", response_model=Token)
async def login_json(user_login: UserLogin):
    """
    Alternative login endpoint accepting JSON.

    Default users:
    - Username: admin, Password: admin123
    - Username: analyst, Password: analyst123
    """
    user = authenticate_user(user_login.username, user_login.password)

    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password"
        )

    if user.get("disabled"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Inactive user"
        )

    access_token_expires = timedelta(
        minutes=settings.access_token_expire_minutes)
    access_token = create_access_token(
        data={"sub": user["username"], "roles": user["roles"]},
        expires_delta=access_token_expires
    )

    return {"access_token": access_token, "token_type": "bearer"}


@router.get("/me", response_model=User)
async def read_users_me(current_user: dict = Depends(get_current_user)):
    """Get current user information."""
    username = current_user["username"]
    user_data = fake_users_db.get(username)

    if not user_data:
        raise HTTPException(status_code=404, detail="User not found")

    return User(
        username=user_data["username"],
        email=user_data["email"],
        full_name=user_data["full_name"],
        roles=user_data["roles"],
        disabled=user_data["disabled"]
    )
