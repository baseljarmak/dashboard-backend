from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, status
from typing import List
import shutil
from pathlib import Path
import time
from app.models.schemas import (
    FilterRequest,
    CubeData,
    DataSummary,
    CSVUploadResponse,
    AvailableSegments,
    ChartData
)
from app.services.data_service import get_data_service, DataService
from app.core.security import get_current_user, check_permission
from app.core.config import get_settings

settings = get_settings()
router = APIRouter(prefix="/data", tags=["Data"])


@router.post("/upload", response_model=CSVUploadResponse)
async def upload_csv(
    file: UploadFile = File(...),
    current_user: dict = Depends(check_permission(["admin", "analyst"]))
):
    """
    Upload CSV file for processing.
    
    Requires: admin or analyst role
    Max file size: Configured in settings (default 500MB)
    """
    # Validate file type
    if not file.filename.endswith('.csv'):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Only CSV files are allowed"
        )
    
    # Create data directory if it doesn't exist
    data_dir = Path(settings.data_path)
    data_dir.mkdir(parents=True, exist_ok=True)
    
    # Save uploaded file
    file_path = data_dir / file.filename
    
    try:
        with file_path.open("wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to save file: {str(e)}"
        )
    
    # Load into DuckDB
    data_service = get_data_service()
    
    try:
        load_stats = data_service.load_csv(str(file_path))
        
        return CSVUploadResponse(
            filename=file.filename,
            rows_processed=load_stats["rows_processed"],
            columns=load_stats["columns"],
            file_size_mb=load_stats["file_size_mb"],
            processing_time_ms=load_stats["processing_time_ms"],
            status="success",
            message=f"Successfully loaded {load_stats['rows_processed']:,} rows"
        )
    except Exception as e:
        # Clean up file on error
        file_path.unlink(missing_ok=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to process CSV: {str(e)}"
        )


@router.get("/dimensions", response_model=AvailableSegments)
async def get_dimensions(
    current_user: dict = Depends(get_current_user)
):
    """
    Get all available dimensions/segments in the dataset.
    
    Returns:
    - segments: Categorical columns
    - categories: Same as segments
    - date_columns: Date/timestamp columns
    - numeric_columns: Numeric columns for metrics
    """
    data_service = get_data_service()
    
    if not data_service.data_loaded:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No data loaded. Please upload a CSV file first."
        )
    
    dimensions = data_service.get_available_dimensions()
    
    return AvailableSegments(**dimensions)


@router.post("/cube", response_model=CubeData)
async def create_cube(
    filter_req: FilterRequest,
    current_user: dict = Depends(get_current_user)
):
    """
    Create OLAP cube with specified filters and aggregations.
    
    Example request:
    {
        "date_range": {
            "start_date": "2024-01-01",
            "end_date": "2024-12-31"
        },
        "segments": ["category", "region"],
        "group_by": ["category", "region"],
        "metrics": ["revenue", "quantity"],
        "aggregation": "sum",
        "limit": 1000
    }
    """
    data_service = get_data_service()
    
    if not data_service.data_loaded:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No data loaded. Please upload a CSV file first."
        )
    
    try:
        cube_data = data_service.create_cube(filter_req)
        return CubeData(**cube_data)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create cube: {str(e)}"
        )


@router.get("/summary", response_model=DataSummary)
async def get_summary(
    current_user: dict = Depends(get_current_user)
):
    """
    Get summary statistics of the loaded dataset.
    
    Returns:
    - Total records
    - Date range (if applicable)
    - Available segments
    - Metric summaries (sum, avg, min, max)
    """
    data_service = get_data_service()
    
    if not data_service.data_loaded:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No data loaded. Please upload a CSV file first."
        )
    
    try:
        summary = data_service.get_summary()
        return DataSummary(**summary)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get summary: {str(e)}"
        )


@router.post("/chart", response_model=ChartData)
async def get_chart_data(
    filter_req: FilterRequest,
    current_user: dict = Depends(get_current_user)
):
    """
    Get data formatted for chart visualization.
    
    This is a convenience endpoint that returns data in a format
    optimized for frontend charting libraries like ECharts.
    """
    data_service = get_data_service()
    
    if not data_service.data_loaded:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No data loaded. Please upload a CSV file first."
        )
    
    try:
        # Get cube data
        cube_data = data_service.create_cube(filter_req)
        
        # Transform to chart format
        if not cube_data["data"]:
            return ChartData(
                title="No Data",
                labels=[],
                datasets=[],
                total_records=0
            )
        
        # Extract labels from first dimension
        labels = []
        datasets = []
        
        if cube_data["dimensions"]:
            first_dim = cube_data["dimensions"][0]
            labels = [str(row.get(first_dim, "Unknown")) for row in cube_data["data"]]
        
        # Create dataset for each measure
        for measure in cube_data["measures"]:
            # Find the aggregated column name
            agg_col = f"{measure}_{filter_req.aggregation or 'sum'}"
            
            values = [
                float(row.get(agg_col, 0)) 
                for row in cube_data["data"]
            ]
            
            datasets.append({
                "name": measure,
                "data": values,
                "type": "bar"  # Default chart type
            })
        
        return ChartData(
            title=f"Data by {', '.join(cube_data['dimensions']) if cube_data['dimensions'] else 'All'}",
            labels=labels,
            datasets=datasets,
            total_records=cube_data["total_records"],
            metadata={
                "query_time_ms": cube_data["query_time_ms"],
                "dimensions": cube_data["dimensions"],
                "measures": cube_data["measures"]
            }
        )
    
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create chart data: {str(e)}"
        )


@router.delete("/clear")
async def clear_data(
    current_user: dict = Depends(check_permission(["admin"]))
):
    """
    Clear all loaded data (admin only).
    
    Requires: admin role
    """
    data_service = get_data_service()
    
    try:
        # Recreate data service to clear memory
        data_service.conn.execute(f"DROP TABLE IF EXISTS {data_service.table_name}")
        data_service.data_loaded = False
        
        return {
            "status": "success",
            "message": "All data cleared successfully"
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to clear data: {str(e)}"
        )
