from pydantic import BaseModel, Field, validator
from typing import Optional, List, Dict, Any
from datetime import datetime, date
from enum import Enum


# Authentication Models
class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class TokenData(BaseModel):
    username: Optional[str] = None
    roles: List[str] = []


class UserLogin(BaseModel):
    username: str
    password: str


class User(BaseModel):
    username: str
    email: Optional[str] = None
    full_name: Optional[str] = None
    roles: List[str] = []
    disabled: bool = False


# Data Filter Models
class DateRange(BaseModel):
    start_date: date
    end_date: date

    @validator('end_date')
    def end_after_start(cls, v, values):
        if 'start_date' in values and v < values['start_date']:
            raise ValueError('end_date must be after start_date')
        return v


class FilterRequest(BaseModel):
    """Request model for filtering data."""
    date_range: Optional[DateRange] = None
    segments: Optional[List[str]] = Field(
        None, description="List of segments to filter")
    categories: Optional[List[str]] = Field(
        None, description="List of categories to filter")
    metrics: Optional[List[str]] = Field(
        None, description="Metrics to include")
    group_by: Optional[List[str]] = Field(
        None, description="Fields to group by")
    aggregation: Optional[str] = Field(
        "sum", description="Aggregation function: sum, avg, count, min, max")
    limit: Optional[int] = Field(
        1000, ge=1, le=10000, description="Maximum records to return")
    offset: Optional[int] = Field(0, ge=0, description="Offset for pagination")


class AggregationType(str, Enum):
    SUM = "sum"
    AVG = "avg"
    COUNT = "count"
    MIN = "min"
    MAX = "max"


# Data Response Models
class DataPoint(BaseModel):
    """Single data point in a series."""
    label: str
    value: float
    metadata: Optional[Dict[str, Any]] = None


class ChartData(BaseModel):
    """Chart data response."""
    title: str
    labels: List[str]
    datasets: List[Dict[str, Any]]
    total_records: int
    metadata: Optional[Dict[str, Any]] = None


class CubeData(BaseModel):
    """OLAP cube data response."""
    dimensions: List[str]
    measures: List[str]
    data: List[Dict[str, Any]]
    total_records: int
    query_time_ms: float


class MetricStats(BaseModel):
    """Statistics for a single metric."""
    sum: float
    avg: float
    min: float
    max: float


class DataSummary(BaseModel):
    """Summary statistics for dataset."""
    total_records: int
    date_range: Optional[DateRange] = None
    segments: List[str]
    categories: List[str]
    metrics: Dict[str, MetricStats]  # ✅ CORRECT - nested structure
    last_updated: datetime


# CSV Upload Models
class CSVUploadResponse(BaseModel):
    """Response after CSV upload."""
    filename: str
    rows_processed: int
    columns: List[str]
    file_size_mb: float
    processing_time_ms: float
    status: str
    message: str


class AvailableSegments(BaseModel):
    """Available segments/dimensions in the dataset."""
    segments: List[str]
    categories: List[str]
    date_columns: List[str]
    numeric_columns: List[str]


# Error Response
class ErrorResponse(BaseModel):
    """Standard error response."""
    detail: str
    error_code: Optional[str] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)
