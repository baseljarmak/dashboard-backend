import duckdb
import polars as pl
from pathlib import Path
from typing import List, Dict, Any, Optional
from datetime import datetime
import time
from app.core.config import get_settings
from app.models.schemas import FilterRequest, AggregationType

settings = get_settings()


class DataService:
    """Service for ETL operations and data cube creation using DuckDB."""

    def __init__(self, db_path: str = ":memory:"):
        """Initialize DuckDB connection."""
        self.conn = duckdb.connect(db_path)
        self.data_loaded = False
        self.table_name = "main_data"

    def load_csv(self, csv_path: str, table_name: Optional[str] = None) -> Dict[str, Any]:
        """
        Load CSV file into DuckDB.

        Args:
            csv_path: Path to CSV file
            table_name: Optional table name (defaults to self.table_name)

        Returns:
            Dictionary with load statistics
        """
        start_time = time.time()
        table = table_name or self.table_name

        # Get file size
        file_size = Path(csv_path).stat().st_size / (1024 * 1024)  # MB

        # Load CSV directly with DuckDB (very fast for large files)
        self.conn.execute(f"""
            CREATE OR REPLACE TABLE {table} AS 
            SELECT * FROM read_csv_auto('{csv_path}', 
                header=true,
                sample_size=100000,
                null_padding=true
            )
        """)

        # Get row count and column info
        row_count = self.conn.execute(
            f"SELECT COUNT(*) FROM {table}").fetchone()[0]
        columns = [desc[0]
                   for desc in self.conn.execute(f"DESCRIBE {table}").fetchall()]

        processing_time = (time.time() - start_time) * 1000  # ms

        self.data_loaded = True

        return {
            "rows_processed": row_count,
            "columns": columns,
            "file_size_mb": round(file_size, 2),
            "processing_time_ms": round(processing_time, 2),
            "table_name": table
        }

    def get_available_dimensions(self) -> Dict[str, List[str]]:
        """Get all available dimensions/columns from the dataset."""
        if not self.data_loaded:
            return {"segments": [], "categories": [], "date_columns": [], "numeric_columns": []}

        # Get column types
        schema = self.conn.execute(f"DESCRIBE {self.table_name}").fetchall()

        segments = []
        numeric_columns = []
        date_columns = []

        for col_name, col_type, *_ in schema:
            col_type = col_type.upper()

            if 'VARCHAR' in col_type or 'TEXT' in col_type:
                segments.append(col_name)
            elif 'DATE' in col_type or 'TIMESTAMP' in col_type:
                date_columns.append(col_name)
            elif any(num_type in col_type for num_type in ['INTEGER', 'BIGINT', 'DOUBLE', 'DECIMAL', 'NUMERIC', 'FLOAT']):
                numeric_columns.append(col_name)

        return {
            "segments": segments,
            "categories": segments,  # In this context, same as segments
            "date_columns": date_columns,
            "numeric_columns": numeric_columns
        }

    def create_cube(self, filter_req: FilterRequest) -> Dict[str, Any]:
        """
        Create OLAP cube based on filter request.

        Args:
            filter_req: Filter and aggregation parameters

        Returns:
            Cube data with dimensions and measures
        """
        start_time = time.time()

        # Build SQL query
        where_clauses = []

        # Date range filter
        if filter_req.date_range and self.get_available_dimensions()["date_columns"]:
            date_col = self.get_available_dimensions(
            )["date_columns"][0]  # Use first date column
            where_clauses.append(
                f"{date_col} BETWEEN '{filter_req.date_range.start_date}' AND '{filter_req.date_range.end_date}'"
            )

        # Segment filters
        if filter_req.segments:
            segment_filters = " OR ".join([
                f"{seg} IS NOT NULL" for seg in filter_req.segments
                if seg in self.get_available_dimensions()["segments"]
            ])
            if segment_filters:
                where_clauses.append(f"({segment_filters})")

        # Build WHERE clause
        where_sql = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ""

        # Determine grouping columns
        group_by_cols = filter_req.group_by or []
        if not group_by_cols and filter_req.segments:
            # Default to first 3 segments
            group_by_cols = filter_req.segments[:3]

        # Determine aggregation columns
        numeric_cols = self.get_available_dimensions()["numeric_columns"]
        # Default to first 5 numeric columns
        agg_cols = filter_req.metrics or numeric_cols[:5]

        # Build aggregation
        agg_func = filter_req.aggregation or "sum"
        agg_expressions = [
            f"{agg_func.upper()}({col}) as {col}_{agg_func}"
            for col in agg_cols if col in numeric_cols
        ]

        if not agg_expressions:
            agg_expressions = ["COUNT(*) as count"]

        # Build GROUP BY
        group_by_sql = f"GROUP BY {', '.join(group_by_cols)}" if group_by_cols else ""

        # Extract just the aggregation part for ORDER BY (without the alias)
        if agg_expressions[0] == "COUNT(*) as count":
            order_by_clause = "COUNT(*)"
        else:
            # Extract the aggregation function before "as"
            first_agg = agg_expressions[0].split(" as ")[0]
            order_by_clause = first_agg

        # Build final query
        select_cols = group_by_cols + agg_expressions
        query = f"""
            SELECT {', '.join(select_cols)}
            FROM {self.table_name}
            {where_sql}
            {group_by_sql}
            ORDER BY {order_by_clause} DESC
            LIMIT {filter_req.limit}
            OFFSET {filter_req.offset}
        """

        # Execute query
        result = self.conn.execute(query).fetchall()
        columns = [desc[0] for desc in self.conn.description]

        # Convert to list of dicts
        data = [dict(zip(columns, row)) for row in result]

        # Get total count
        count_query = f"""
            SELECT COUNT(*) 
            FROM {self.table_name}
            {where_sql}
        """
        total_records = self.conn.execute(count_query).fetchone()[0]

        query_time = (time.time() - start_time) * 1000

        return {
            "dimensions": group_by_cols,
            "measures": agg_cols,
            "data": data,
            "total_records": total_records,
            "query_time_ms": round(query_time, 2)
        }

    def get_summary(self) -> Dict[str, Any]:
        """Get summary statistics of the dataset."""
        if not self.data_loaded:
            return {}

        # Get basic stats
        total_records = self.conn.execute(
            f"SELECT COUNT(*) FROM {self.table_name}").fetchone()[0]

        # Get date range if date columns exist
        date_cols = self.get_available_dimensions()["date_columns"]
        date_range = None
        if date_cols:
            date_col = date_cols[0]
            date_stats = self.conn.execute(f"""
                SELECT MIN({date_col}), MAX({date_col})
                FROM {self.table_name}
            """).fetchone()
            if date_stats[0] and date_stats[1]:
                date_range = {
                    "start_date": str(date_stats[0]),
                    "end_date": str(date_stats[1])
                }

        # Get unique segments
        segment_cols = self.get_available_dimensions()["segments"][:3]
        segments = []
        for col in segment_cols:
            unique_vals = self.conn.execute(f"""
                SELECT DISTINCT {col} FROM {self.table_name} 
                WHERE {col} IS NOT NULL 
                LIMIT 100
            """).fetchall()
            segments.extend([str(v[0]) for v in unique_vals])

        # Get numeric column stats
        numeric_cols = self.get_available_dimensions()["numeric_columns"]
        metrics = {}
        for col in numeric_cols[:5]:
            stats = self.conn.execute(f"""
                SELECT 
                    SUM({col}) as total,
                    AVG({col}) as average,
                    MIN({col}) as minimum,
                    MAX({col}) as maximum
                FROM {self.table_name}
            """).fetchone()

            metrics[col] = {
                "sum": float(stats[0]) if stats[0] else 0,
                "avg": float(stats[1]) if stats[1] else 0,
                "min": float(stats[2]) if stats[2] else 0,
                "max": float(stats[3]) if stats[3] else 0
            }

        return {
            "total_records": total_records,
            "date_range": date_range,
            "segments": list(set(segments)),
            "categories": segment_cols,
            "metrics": metrics,
            "last_updated": datetime.utcnow().isoformat()
        }

    def close(self):
        """Close DuckDB connection."""
        self.conn.close()


# Global instance (singleton pattern)
_data_service = None


def get_data_service() -> DataService:
    """Get or create DataService instance."""
    global _data_service
    if _data_service is None:
        _data_service = DataService()
    return _data_service
