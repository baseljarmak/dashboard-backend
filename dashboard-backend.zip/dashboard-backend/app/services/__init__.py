# App package
"""Business logic and data services."""

from app.services.data_service import DataService, get_data_service

__all__ = [
    "DataService",
    "get_data_service",
]
